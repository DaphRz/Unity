using UnityEngine;

public class FollowPlayer : MonoBehaviour
{
    // Reference to the Player Object
    public GameObject player; 
    private Vector3 offset = new Vector3(0.03f, 3.88f, -8.48f);

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Ele vai atualizar a posição da camera depois que o player se mover
    void LateUpdate()
    {
        // transform.position = player.transform.position; - posição do player = 0,0,0

        // posição do player + offset (posição da camera)
        // transform.position = player.transform.position + new Vector3(0.03f, 3.88f, -8.48f); 

        transform.position = player.transform.position + offset;
    }
}

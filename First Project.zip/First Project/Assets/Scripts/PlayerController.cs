using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerController : MonoBehaviour
{
    // Editable in Inspector
    public float speed = 10.0f;
    public float turnSpeed;

    // Input System Action exposed in Inspector for binding (WASD)
    public InputAction moveAction;
    public Vector2 moveInput; // Private for Security - deixei 'public' p debug e visualização


    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        // Enable the MoveAction so its starts reading input
        moveAction.Enable();
    }
    

    // Update is called once per frame - os pc's atualizam a tela 60 vezes por segundo, ou seja, 60 frames por segundo (varia de pc pra c)
    void Update()
    {
        // Move Vehicle forward
        // transform.Translate(0,0,1) = transform.Translate(Vector3.forward) - "para frente"
        // transform.Translate(Vector3.forward * Time.deltaTime * 20); // * 1s (controlar o 'frame') * 20 (20m por s)

        // Read the 2D vector from the MoveAction (x = horiz, y = vert)
        moveInput = moveAction.ReadValue<Vector2>();

        // Forward | Backward - along local z using the y component 
        transform.Translate(Vector3.forward * Time.deltaTime * speed * moveInput.y);

        // Left | Right
        // transform.Translate(Vector3.right * Time.deltaTime * speed * moveInput.x) - anda lateralmente
        // Rotate around local y using the x component
        transform.Rotate(Vector3.up * Time.deltaTime * turnSpeed * moveInput.x);    // rotaciona o player
    }
}

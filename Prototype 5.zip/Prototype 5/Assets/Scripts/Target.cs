using UnityEngine;
using UnityEngine.InputSystem;

public class Target : MonoBehaviour
{
    private Rigidbody targetRb;

    private float minSpeed = 60;
    private float maxSpeed = 85;
    private float maxTorque = 10;
    private float xRange = 5;
    private float ySpawnPos = -5;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        targetRb = GetComponent<Rigidbody>();

        /// força de impulso pra cima on a randomized speed
        // targetRb.AddForce(Vector3.up * Random.Range(12,16), ForceMode.Impulse);
        // targetRb.AddForce(Vector3.up * Random.Range(minSpeed, maxSpeed), ForceMode.Impulse);

        targetRb.AddForce(RandomForce(), ForceMode.Impulse);

        /// rotates at x, y, z
        // targetRb.AddTorque(Random.Range(-10,10), Random.Range(-10,10), Random.Range(-10,10), ForceMode.Impulse);
        // targetRb.AddTorque(Random.Range(-maxTorque, maxTorque), Random.Range(-maxTorque, maxTorque), Random.Range(-maxTorque, maxTorque), ForceMode.Impulse);

        targetRb.AddTorque(RandomTorque(), RandomTorque(), RandomTorque(), ForceMode.Impulse);

        /// spawnar aleatoriamente no x
        // transform.position = new Vector3(Random.Range(-4,4), -6); // -6 = fora da visão do player, 0 = posso omitir
        // transform.position = new Vector3(Random.Range(-xRange, xRange), ySpawnPos);

        transform.position = RandomSpawnPos();
    }

    // Update is called once per frame
    void Update()
    {
        if (Mouse.current.leftButton.wasPressedThisFrame)
        {
            Debug.Log("Mouse was clicked!");

            Ray ray = Camera.main.ScreenPointToRay(Mouse.current.position.ReadValue());
            Debug.DrawRay(ray.origin, ray.direction * 100f, Color.red, 2f);
        }
    }

    Vector3 RandomForce()
    {
        return Vector3.up * Random.Range(minSpeed, maxSpeed); // não usa new pq o obj já existe
    }

    float RandomTorque()
    {
        return Random.Range(-maxTorque, maxTorque);
    }

    Vector3 RandomSpawnPos()
    {
        return new Vector3(Random.Range(-xRange, xRange), ySpawnPos); // está criando um novo Vector3, então usa-se new
    }
}
using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerController : MonoBehaviour
{
    private Rigidbody playerRB;
    private Animator playerAnimator;
    private AudioSource playerAudio;
    public InputAction jumpAction;
    public ParticleSystem particleSystem;
    public ParticleSystem dirtParticle;
    public AudioClip jumpSound;
    public AudioClip crashSound;

    public float jumpForce = 10;
    public float gravityModifier;
    public bool isOnGround = true;

    public bool gameOver = false;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        playerRB = GetComponent<Rigidbody>();
        playerAnimator = GetComponent<Animator>();
        playerAudio = GetComponent<AudioSource>();

        jumpAction.Enable();

        Physics.gravity *= gravityModifier;
    }

    // Update is called once per frame
    void Update()
    {
        /* if (jumpAction.triggered)
        {
            playerRB.AddForce(Vector3.up * 10, ForceMode.Impulse);
        }*/

        if (jumpAction.triggered && isOnGround && !gameOver) // = gameOver != true
        {
            playerRB.AddForce(Vector3.up * jumpForce, ForceMode.Impulse); // tirando o número e colocando a variável jumpForce, eu consigo mudar ela no Inspector
            isOnGround = false;

            playerAnimator.SetTrigger("Jump_trig");

            dirtParticle.Stop();

            playerAudio.PlayOneShot(jumpSound, 1.0f);
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        // isOnGround = true;

        if (collision.gameObject.CompareTag("Ground"))
        {
            isOnGround = true;
            dirtParticle.Play();
        }
        
        else if (collision.gameObject.CompareTag("Obstacle"))
        {
            gameOver = true;
            Debug.Log("Game Over!");

            particleSystem.Play();

            playerAnimator.SetBool("Death_b", true);
            playerAnimator.SetInteger("DeathType_int", 1);

            dirtParticle.Stop();

            playerAudio.PlayOneShot(crashSound, 2.0f);
        }
    }
}

Shader "Simple/Unlit Vertex Color_Alpha" 
{

Properties {
    _MainTex ("Base (RGB)", 2D) = "white" {}
	_Color ("Color", Color) = (1,1,1,1)
}

SubShader 
{
   	   Tags 
	   { 
		"Queue"="Transparent" 
	    "IgnoreProjector"="True" 
	    "RenderType"="Transparent" 
	   }

	   Lighting Off 
	   ZWrite Off 
	   Fog { Mode Off }

	   Blend SrcAlpha OneMinusSrcAlpha

  
	BindChannels {
		Bind "Color", color
		Bind "Vertex", vertex
		Bind "texcoord", texcoord
	}
   
   Pass {
        ColorMaterial AmbientAndDiffuse

        SetTexture [_MainTex] 
		{
			constantColor [_Color]
			Combine texture * primary * constant
        }
    }
}
}
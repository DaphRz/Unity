using UnityEngine;
using UnityEngine.InputSystem;
//using System.Security.Cryptography;

public class PlayerController : MonoBehaviour
{
    public InputAction moveAction;
    public Vector2 moveInput;

    public float speed = 10.0f;
    public float xRange = 18.0f;

    public GameObject projectilePrefab;
    public InputAction fireAction;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        // to activate the Input
        moveAction.Enable();  
        fireAction.Enable();
    }

    // Update is called once per frame
    void Update()
    {
        moveInput = moveAction.ReadValue<Vector2>();
        transform.Translate(Vector3.right * moveInput.x * Time.deltaTime * speed); // .right = (1,0,0)

        // Keep the player in bounds
        if (transform.position.x < -xRange)
        {
            transform.position = new Vector3(-xRange, transform.position.y, transform.position.z); // vai parar exatamente em '-20' e ñ vai mudar y e z
        }
        if (transform.position.x > xRange)
        {
            transform.position = new Vector3(xRange, transform.position.y, transform.position.z);
        }

        if (fireAction.triggered)
        {
            // Debug.Log("PEI") - aparece no 'Console'

            // Launch a projectile from the player
            // Instantiate = criar um Objeto (cópias de objetos q já existem)
            Instantiate(projectilePrefab, transform.position, projectilePrefab.transform.rotation);  // (qual objeto, onde sera spawnado (posicao do player), rotacao (0))
        }
    }
}
using UnityEngine;

public class DetectCollisions : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnTriggerEnter(Collider other)
    {
        Destroy(gameObject);        // destrói o animal (colocou esse Script nele)
        Destroy(other.gameObject);  // destrói oq colide (food) - se eu colocasse esse Script nele, dava certo sem esse comando tb
    }
}
